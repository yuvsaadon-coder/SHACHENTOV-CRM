# שכן טוב — מערכת CRM

מערכת ניהול תפעולי לעמותת שכן טוב. React 18 + Vite + TypeScript + Tailwind + Firebase.

## הרצה מקומית

```bash
npm install
# העתק env.example.txt ל-.env ומלא ערכים
npm run dev
```

## פריסה ל-Netlify

- Build command: `npm run build`
- Publish directory: `dist`
- הוסף את כל `VITE_FIREBASE_*` ב-Netlify Site settings → Environment variables

## Firebase Console

- Authentication → Sign-in method → Email/Password → Enable
- Firestore → Rules → הדבק את תוכן `firestore.rules` → Publish

## כניסה ראשונה

סיסמה לכל המשתמשים: `Shachen2027!` — יש לשנות אחרי כניסה ראשונה.

| תחום | אימייל |
|---|---|
| מנכ"ל (admin) | ceo@shachentov.org.il |
| סניפי ירושלים | jfood@shachentov.org.il |
| ספקים | projects@shachentov.org.il |
| כספים | cfo@shachentov.org.il |
| תרומות | trumot@shachentov.org.il |
| עיצובים | media@shachentov.org.il |
| פרסומים | pub@shachentov.org.il |
| מתנדבים | volunteers.m@shachentov.org.il |
