/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          teal: '#189A9F',
          tealDark: '#147F84',
          teal050: '#E6F4F4',
          navy: '#141348',
          navy2: '#3A3A6B',
          yellow: '#FDC857',
        },
        status: {
          done: '#C6EFCE',
          work: '#189A9F',
          wait: '#FDC857',
          todo: '#EEF2F2',
          other: '#E4DFEC',
        },
      },
      fontFamily: {
        sans: ['Rubik', 'Heebo', 'Assistant', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
}
