// Admin Dashboard — שכן טוב (Firebase edition)
const { useState, useMemo, useEffect, useCallback } = React;

// ---- Contexts ----
const VotesContext  = React.createContext({});
const ConfigContext = React.createContext(null); // { products, coordinators, baskets, saveConfig }

// ---- Firebase helpers ----
async function clearAllVotes() {
  const snap = await window.db.collection('votes').get();
  const batch = window.db.batch();
  snap.forEach(doc => batch.delete(doc.ref));
  await batch.commit();
}

async function loadFirebaseConfig() {
  try {
    const doc = await window.db.collection('config').doc('main').get();
    if (doc.exists) return doc.data();
  } catch (e) { console.warn('Config load failed, using data.js defaults', e); }
  return null;
}

async function saveFirebaseConfig(cfg) {
  // הסר פונקציות — Firebase לא יכול לשמור אותן
  const { saveConfig, ...data } = cfg;
  await window.db.collection('config').doc('main').set(data);
}

// ---- Smart basket alignment ----
// Detects if a coordinator filled A+B "flipped" relative to the majority, and corrects it
function alignVotes(VOTES, coordinators) {
  const pairs = [['a', 'b'], ['a_ext', 'b_ext']];
  const aligned = {};
  for (const c of coordinators) {
    aligned[c.id] = VOTES[c.id] ? { ...VOTES[c.id] } : null;
  }

  for (const [bA, bB] of pairs) {
    // Two-pass alignment
    for (let pass = 0; pass < 2; pass++) {
      // Build reference aggregate for basket A
      const aggA = {};
      for (const c of coordinators) {
        const v = aligned[c.id];
        if (!v) continue;
        for (const [pid, qty] of Object.entries(v[bA] || {})) {
          aggA[pid] = (aggA[pid] || 0) + qty * c.weight;
        }
      }
      if (!Object.keys(aggA).length) break;

      // For each coordinator: compare similarity in normal vs swapped order
      for (const c of coordinators) {
        const v = aligned[c.id];
        if (!v) continue;
        const vA = v[bA] || {}, vB = v[bB] || {};
        let simSame = 0, simSwap = 0;
        for (const [pid, aggQty] of Object.entries(aggA)) {
          simSame += Math.min(vA[pid] || 0, aggQty);
          simSwap += Math.min(vB[pid] || 0, aggQty);
        }
        if (simSwap > simSame) {
          aligned[c.id] = { ...v, [bA]: vB, [bB]: vA };
        }
      }
    }
  }
  return aligned;
}

// ---- Computation ----
function computeWeightedResults(VOTES, config) {
  const products     = config.products;
  const coordinators = config.coordinators;
  const baskets      = config.baskets;

  const alignedVotes = alignVotes(VOTES, coordinators);
  const result = {};

  for (const basket of baskets) {
    const scores = {};
    let totalVoters = 0, totalWeight = 0;
    for (const coord of coordinators) {
      const vote = alignedVotes[coord.id];
      if (!vote) continue;
      totalVoters++;
      totalWeight += coord.weight;
      for (const [pid, qty] of Object.entries(vote[basket.id] || {})) {
        scores[pid] = (scores[pid] || 0) + qty * coord.weight;
      }
    }
    const ranked = Object.entries(scores)
      .map(([pid, score]) => {
        const p = products.find(x => x.id === pid);
        return p ? { pid, score, name: p.name, price: p.price, emoji: p.emoji, max: p.max } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);

    const winners = [];
    let used = 0;
    for (const item of ranked) {
      let pickedBy = 0, qtySum = 0;
      for (const coord of coordinators) {
        const vote = alignedVotes[coord.id];
        if (!vote) continue;
        const q = (vote[basket.id] || {})[item.pid] || 0;
        if (q > 0) { pickedBy++; qtySum += q; }
      }
      const avgQty = Math.max(1, Math.round(qtySum / Math.max(1, pickedBy)));
      const cost = avgQty * item.price;
      if (used + cost <= basket.budget) {
        winners.push({ ...item, qty: avgQty, cost, pickedBy });
        used += cost;
      }
    }
    const selectedIds = new Set(winners.map(w => w.pid));
    const tieGroups = {};
    for (const r of ranked) {
      if (selectedIds.has(r.pid)) continue;
      const k = r.score.toFixed(2);
      tieGroups[k] = tieGroups[k] || [];
      tieGroups[k].push(r);
    }
    const flaggedTies = Object.values(tieGroups)
      .filter(g => g.length > 1 && g[0].score >= (ranked[Math.min(ranked.length-1, winners.length)] || {score:0}).score - 0.5);

    result[basket.id] = { basket, winners, used, ranked, ties: flaggedTies, totalVoters, totalWeight };
  }
  return result;
}

// ---- Optimal basket (merged A+B, ext A+B) ----
function computeOptimalBasket(VOTES, config) {
  const { products, coordinators } = config;
  const alignedVotes = alignVotes(VOTES, coordinators);

  function poolBaskets(b1, b2, budget) {
    const scores = {};
    for (const coord of coordinators) {
      const v = alignedVotes[coord.id];
      if (!v) continue;
      for (const bid of [b1, b2]) {
        for (const [pid, qty] of Object.entries(v[bid] || {})) {
          scores[pid] = (scores[pid] || 0) + qty * coord.weight;
        }
      }
    }
    const ranked = Object.entries(scores)
      .map(([pid, score]) => {
        const p = products.find(x => x.id === pid);
        return p ? { pid, score, name: p.name, price: p.price, emoji: p.emoji } : null;
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);

    const winners = [];
    let used = 0;
    for (const item of ranked) {
      let pickedBy = 0, qtySum = 0;
      for (const coord of coordinators) {
        const v = alignedVotes[coord.id];
        if (!v) continue;
        const q = ((v[b1] || {})[item.pid] || 0) + ((v[b2] || {})[item.pid] || 0);
        if (q > 0) { pickedBy++; qtySum += q / 2; }
      }
      const avgQty = Math.max(1, Math.round(qtySum / Math.max(1, pickedBy)));
      const cost = avgQty * item.price;
      if (used + cost <= budget) {
        winners.push({ ...item, qty: avgQty, cost, pickedBy });
        used += cost;
      }
    }
    return { winners, used, ranked, budget };
  }

  const mainBudget = config.baskets.filter(b => b.id === 'a' || b.id === 'b').reduce((s,b) => s + b.budget, 0) / 2;
  const extBudget  = config.baskets.filter(b => b.id === 'a_ext' || b.id === 'b_ext').reduce((s,b) => s + b.budget, 0) / 2;

  return {
    main: poolBaskets('a', 'b', mainBudget),
    ext:  poolBaskets('a_ext', 'b_ext', extBudget),
  };
}

// ---- Time helper ----
function relTime(ts) {
  const diff = Date.now() - ts;
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'הרגע';
  if (m < 60) return `לפני ${m} דק'`;
  const h = Math.floor(m / 60);
  if (h < 24) return `לפני ${h} שעות`;
  return `לפני ${Math.floor(h / 24)} ימים`;
}

// ---- CSV export helper ----
function downloadCSV(rows, filename) {
  const csv = '\uFEFF' + rows.map(r => r.map(c => `"${String(c).replace(/"/g,'""')}"`).join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href = url; a.download = filename; a.click();
  URL.revokeObjectURL(url);
}

// ---- App ----
function AdminApp() {
  const [tab, setTab] = useState('status');
  const [votes, setVotes]     = useState({});
  const [config, setConfig]   = useState(null); // null = loading
  const [roundNum, setRoundNum]   = useState(14);
  const [roundOpen, setRoundOpen] = useState(true);
  const [roundOpenedAt] = useState(() => Date.now() - 3 * 24 * 60 * 60 * 1000);

  // Load config from Firebase (falls back to data.js)
  useEffect(() => {
    loadFirebaseConfig().then(fb => {
      setConfig(fb || {
        products:     window.APP_DATA.products,
        coordinators: window.APP_DATA.coordinators,
        baskets:      window.APP_DATA.baskets,
      });
    });
  }, []);

  // Realtime votes from Firebase
  useEffect(() => {
    const unsub = window.db.collection('votes').onSnapshot(snap => {
      const v = {};
      snap.forEach(doc => { v[doc.id] = doc.data(); });
      setVotes(v);
    }, err => console.error('Firebase votes error:', err));
    return () => unsub();
  }, []);

  const saveConfig = useCallback(async (newCfg) => {
    setConfig(newCfg);
    try {
      await saveFirebaseConfig(newCfg);
    } catch (e) {
      alert('שגיאה בשמירה: ' + e.message);
    }
  }, []);

  async function handleResetRound() {
    if (!confirm('לאפס את הצבעות הסבב הנוכחי? פעולה זו תמחק את כל ההצבעות שנשמרו.')) return;
    await clearAllVotes();
    setVotes({});
  }
  async function handleNewRound() {
    if (!confirm(`לסגור את סבב #${roundNum} ולפתוח סבב #${roundNum + 1}?`)) return;
    await clearAllVotes();
    setVotes({});
    setRoundNum(n => n + 1);
    setRoundOpen(true);
  }
  function handleToggleClose() {
    if (roundOpen && !confirm('לסגור את ההצבעה לסבב הנוכחי?')) return;
    setRoundOpen(o => !o);
  }

  if (!config) return (
    <div style={{ display:'grid', placeItems:'center', minHeight:'100vh', fontSize:18 }}>
      ⏳ טוען הגדרות...
    </div>
  );

  const tabs = [
    { id: 'status',   label: 'סטטוס רכזים' },
    { id: 'results',  label: 'תוצאות משוקללות' },
    { id: 'optimal',  label: '🏆 סל מומלץ' },
    { id: 'compare',  label: 'השוואת רכזים' },
    { id: 'export',   label: 'ייצוא לספק' },
    { id: 'catalog',  label: 'ניהול קטלוג' },
    { id: 'coords',   label: 'ניהול רכזים' },
    { id: 'rounds',   label: 'סבבים' },
  ];

  return (
    <ConfigContext.Provider value={{ ...config, saveConfig }}>
      <VotesContext.Provider value={votes}>
        <div style={{ minHeight: '100vh', background: 'var(--bg)' }}>
          <Header />
          <Tabs tabs={tabs} active={tab} onChange={setTab} />
          <main style={{ maxWidth: 1200, margin: '0 auto', padding: '24px 24px 80px' }}>
            {tab === 'status'  && <StatusPanel />}
            {tab === 'results' && <ResultsPanel />}
            {tab === 'optimal' && <OptimalBasketPanel />}
            {tab === 'compare' && <ComparePanel />}
            {tab === 'export'  && <ExportPanel />}
            {tab === 'catalog' && <CatalogPanel />}
            {tab === 'coords'  && <CoordsPanel />}
            {tab === 'rounds'  && (
              <RoundsPanel
                roundNum={roundNum} roundOpen={roundOpen} roundOpenedAt={roundOpenedAt}
                onReset={handleResetRound} onNewRound={handleNewRound}
                onToggleClose={handleToggleClose}
              />
            )}
          </main>
        </div>
      </VotesContext.Provider>
    </ConfigContext.Provider>
  );
}

function Header() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const submitted = config.coordinators.filter(c => VOTES[c.id]);
  return (
    <div style={{
      background: '#1a1a1a', color: 'white', padding: '16px 24px',
      display: 'flex', alignItems: 'center', gap: 16,
      position: 'sticky', top: 0, zIndex: 5,
    }}>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 11, color: 'var(--accent)', fontWeight: 700, letterSpacing: '0.08em' }}>שכן טוב</div>
        <div style={{ fontSize: 20, fontWeight: 800 }}>לוח אדמין</div>
      </div>
      <div style={{ fontSize: 13, color: '#aaa' }}>
        {submitted.length}/{config.coordinators.length} הצביעו
      </div>
      <a href="index.html" style={{
        padding: '8px 14px', background: 'transparent', color: 'white',
        border: '1.5px solid rgba(255,255,255,0.3)', borderRadius: 4,
        textDecoration: 'none', fontSize: 13, fontWeight: 600,
      }}>← לסקר</a>
    </div>
  );
}

function Tabs({ tabs, active, onChange }) {
  return (
    <div style={{
      background: 'white', borderBottom: '2px solid #1a1a1a',
      padding: '0 24px', display: 'flex', gap: 4, overflowX: 'auto',
      position: 'sticky', top: 56, zIndex: 4,
    }}>
      {tabs.map(t => (
        <button key={t.id} onClick={() => onChange(t.id)} style={{
          padding: '12px 14px', background: 'none', border: 'none',
          borderBottom: active === t.id ? '3px solid var(--accent)' : '3px solid transparent',
          fontFamily: 'inherit', fontSize: 14, fontWeight: active === t.id ? 700 : 500,
          color: active === t.id ? '#1a1a1a' : '#6b5d4d', cursor: 'pointer',
          whiteSpace: 'nowrap', marginBottom: -2,
        }}>{t.label}</button>
      ))}
    </div>
  );
}

// ---- Status panel ----
function StatusPanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const { coordinators } = config;
  const submitted = coordinators.filter(c => VOTES[c.id]);
  const pending   = coordinators.filter(c => !VOTES[c.id]);
  const totalWeight     = coordinators.reduce((s, c) => s + c.weight, 0);
  const submittedWeight = submitted.reduce((s, c) => s + c.weight, 0);
  const branches = new Set(coordinators.map(c => c.branch));

  return (
    <div>
      <SectionHeader title="סטטוס רכזים" subtitle={`${submitted.length} מתוך ${coordinators.length} רכזים השלימו את ההצבעה`} />
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 12, marginBottom: 24 }}>
        <Stat label="הצביעו"              value={`${submitted.length} / ${coordinators.length}`} accent />
        <Stat label="משקל הצבעה שנאסף"   value={`${submittedWeight.toFixed(1)} / ${totalWeight.toFixed(1)}`} />
        <Stat label="מחכים"               value={pending.length} />
        <Stat label="סניפים שהשתתפו"      value={`${new Set(submitted.map(c => c.branch)).size} / ${branches.size}`} />
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(360px, 1fr))', gap: 16 }}>
        <Card title={`✓ הצביעו (${submitted.length})`}><Roster list={submitted} status="done" /></Card>
        <Card title={`⏳ ממתינים (${pending.length})`} accent><Roster list={pending} status="pending" /></Card>
      </div>
      <div style={{ marginTop: 24 }}>
        <Card title="קישור לסקר">
          <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
            <input readOnly value={window.location.origin + window.location.pathname.replace('admin.html','index.html')}
              style={{ ...inputStyle, flex: 1, minWidth: 200, color: '#6b5d4d', fontSize: 13 }} />
            <button onClick={() => { navigator.clipboard.writeText(window.location.origin + window.location.pathname.replace('admin.html','index.html')); alert('הועתק!'); }} style={smallBtnStyle}>
              📋 העתק קישור
            </button>
          </div>
        </Card>
      </div>
    </div>
  );
}

function Roster({ list, status }) {
  const VOTES = React.useContext(VotesContext);
  if (!list.length) return <div style={{ color: '#998877', padding: '12px 4px', fontSize: 14 }}>—</div>;
  return (
    <div style={{ display: 'flex', flexDirection: 'column' }}>
      {list.map(c => {
        const vote = VOTES[c.id];
        return (
          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 4px', borderBottom: '1px dashed #e8dfc8' }}>
            <div style={{
              width: 36, height: 36, borderRadius: '50%',
              background: status === 'done' ? '#E8F5E9' : '#FFF4D6',
              border: '2px solid ' + (status === 'done' ? '#1B5E3F' : '#8A6500'),
              display: 'grid', placeItems: 'center', fontSize: 14, fontWeight: 700,
              color: status === 'done' ? '#1B5E3F' : '#8A6500',
            }}>{status === 'done' ? '✓' : '…'}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>{c.name}</div>
              <div style={{ fontSize: 12, color: '#998877' }}>
                {c.branch} · משקל {c.weight}
                {vote && ' · ' + relTime(vote.submittedAt)}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ---- Results panel ----
function ResultsPanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const results    = useMemo(() => computeWeightedResults(VOTES, config), [VOTES, config]);
  const [openBasket, setOpenBasket] = useState('a');
  const totalTies = Object.values(results).reduce((s, r) => s + r.ties.length, 0);

  function exportResults() {
    const rows = [['סל','מוצר','כמות','מחיר ליח\'','סה"כ','ניקוד','נבחר ע"י']];
    for (const b of config.baskets) {
      for (const w of results[b.id].winners) {
        rows.push([b.name, w.name, w.qty, w.price.toFixed(2), w.cost.toFixed(2), w.score.toFixed(1), w.pickedBy]);
      }
    }
    downloadCSV(rows, 'תוצאות-משוקללות.csv');
  }

  return (
    <div>
      <SectionHeader title="תוצאות משוקללות"
        subtitle="מחושב לפי: כמות × משקל. סלים א׳+ב׳ מיושרים אוטומטית (לא משנה מי מילא מה איפה)." />

      <div style={{ display:'flex', gap:8, marginBottom:16, flexWrap:'wrap', alignItems:'center' }}>
        {config.baskets.map(b => {
          const r = results[b.id];
          const active = openBasket === b.id;
          return (
            <button key={b.id} onClick={() => setOpenBasket(b.id)} style={{
              padding: '10px 16px', background: active ? 'var(--accent)' : 'white',
              color: active ? 'white' : '#1a1a1a',
              border: '2px solid #1a1a1a', borderRadius: 4,
              cursor: 'pointer', fontFamily: 'inherit', fontWeight: 700, fontSize: 14,
              boxShadow: active ? 'none' : '3px 3px 0 #1a1a1a',
            }}>
              {b.name} · ₪{r.used.toFixed(0)}/{b.budget}
              {r.ties.length > 0 && <span style={{ marginRight: 6 }}>⚠️</span>}
            </button>
          );
        })}
        <button onClick={exportResults} style={{ ...smallBtnStyle, marginRight: 'auto' }}>📥 ייצוא CSV</button>
      </div>

      {totalTies > 0 && (
        <div style={{ background:'#FFF4D6', border:'2px solid #8A6500', borderRadius:6, padding:'12px 16px', marginBottom:16, display:'flex', gap:12 }}>
          <div style={{ fontSize: 24 }}>⚠️</div>
          <div><div style={{ fontWeight:700, color:'#8A6500' }}>{totalTies} תיקו(ים) לדיון ידני</div>
          <div style={{ fontSize:13, color:'#8A6500' }}>מוצרים עם ניקוד זהה — נדרשת הכרעה.</div></div>
        </div>
      )}

      {(() => {
        const r = results[openBasket];
        return (
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0,2fr) minmax(0,1fr)', gap: 16 }}>
            <Card title={`סל זוכה: ${r.basket.name}`}>
              <div style={{ marginBottom: 12 }}><BudgetBar used={r.used} budget={r.basket.budget} /></div>
              <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
                <thead>
                  <tr style={{ borderBottom:'2px solid #1a1a1a', textAlign:'right' }}>
                    <th style={th}>#</th><th style={th}>מוצר</th><th style={th}>כמות</th>
                    <th style={th}>מחיר</th><th style={th}>סה"כ</th><th style={th}>ניקוד</th><th style={th}>רכזים</th>
                  </tr>
                </thead>
                <tbody>
                  {r.winners.map((w, i) => (
                    <tr key={w.pid} style={{ borderBottom:'1px dashed #e8dfc8' }}>
                      <td style={td}>{i+1}</td>
                      <td style={{ ...td, fontWeight:600 }}><span style={{ marginLeft:8 }}>{w.emoji}</span>{w.name}</td>
                      <td style={td}>{w.qty}</td>
                      <td style={td}>₪{w.price.toFixed(2)}</td>
                      <td style={td}>₪{w.cost.toFixed(2)}</td>
                      <td style={td}><b>{w.score.toFixed(1)}</b></td>
                      <td style={td}>{w.pickedBy}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </Card>
            <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
              {r.ties.length > 0 && (
                <Card title="⚠️ דורש הכרעה ידנית" accent>
                  {r.ties.map((g, i) => (
                    <div key={i} style={{ marginBottom:12 }}>
                      <div style={{ fontSize:12, color:'#998877', marginBottom:4 }}>ניקוד {g[0].score.toFixed(1)} — {g.length} מוצרים</div>
                      {g.map(item => (
                        <div key={item.pid} style={{ display:'flex', alignItems:'center', gap:10, padding:'8px 10px', background:'#FFF4D6', border:'1px solid #C99A2E', borderRadius:4, marginBottom:4 }}>
                          <div style={{ fontSize:18 }}>{item.emoji}</div>
                          <div style={{ flex:1, fontWeight:600 }}>{item.name}</div>
                        </div>
                      ))}
                    </div>
                  ))}
                </Card>
              )}
              <Card title="לא נבחרו (לפי דירוג)">
                <div style={{ fontSize:13, color:'#6b5d4d', maxHeight:280, overflow:'auto' }}>
                  {r.ranked.filter(item => !r.winners.find(w => w.pid === item.pid)).slice(0,10).map(item => (
                    <div key={item.pid} style={{ display:'flex', alignItems:'center', gap:8, padding:'6px 0', borderBottom:'1px dashed #e8dfc8' }}>
                      <span>{item.emoji}</span>
                      <span style={{ flex:1 }}>{item.name}</span>
                      <span style={{ color:'#998877' }}>{item.score.toFixed(1)} נק'</span>
                    </div>
                  ))}
                </div>
              </Card>
            </div>
          </div>
        );
      })()}
    </div>
  );
}

// ---- Optimal basket panel ----
function OptimalBasketPanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const { main, ext } = useMemo(() => computeOptimalBasket(VOTES, config), [VOTES, config]);
  const totalVotes = config.coordinators.filter(c => VOTES[c.id]).length;

  function exportOptimal() {
    const rows = [['קטגוריה','מוצר','כמות','מחיר ליח\'','סה"כ','ניקוד']];
    for (const w of main.winners) rows.push(['סל ראשי', w.name, w.qty, w.price.toFixed(2), w.cost.toFixed(2), w.score.toFixed(1)]);
    for (const w of ext.winners)  rows.push(['הרחבה',   w.name, w.qty, w.price.toFixed(2), w.cost.toFixed(2), w.score.toFixed(1)]);
    downloadCSV(rows, 'סל-מומלץ.csv');
  }

  if (!totalVotes) return (
    <div><SectionHeader title="🏆 הסל המומלץ" subtitle="עדיין אין הצבעות — הסל יחושב כשרכזים יתחילו לשלוח." /></div>
  );

  return (
    <div>
      <SectionHeader title="🏆 הסל המומלץ"
        subtitle="ממוצע א׳+ב׳ מאוחד — המערכת מיישרת אוטומטית ומחשבת את המוצרים עם הניקוד הגבוה ביותר בסל." />
      <div style={{ display:'flex', gap:8, marginBottom:20 }}>
        <button onClick={exportOptimal} style={primaryBtnStyle}>📥 ייצוא CSV</button>
      </div>
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(400px,1fr))', gap:16 }}>
        <BasketOptCard title="🧺 סל ראשי (ממוצע א׳+ב׳)" result={main} />
        <BasketOptCard title="➕ הרחבה (ממוצע הרחבה א׳+ב׳)" result={ext} />
      </div>
    </div>
  );
}

function BasketOptCard({ title, result }) {
  const total = result.winners.reduce((s, w) => s + w.cost, 0);
  return (
    <Card title={title}>
      <div style={{ marginBottom:12 }}><BudgetBar used={result.used} budget={result.budget} /></div>
      <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
        <thead>
          <tr style={{ borderBottom:'2px solid #1a1a1a', textAlign:'right' }}>
            <th style={th}>#</th><th style={th}>מוצר</th><th style={th}>כמות</th>
            <th style={th}>מחיר</th><th style={th}>סה"כ</th><th style={th}>ניקוד</th>
          </tr>
        </thead>
        <tbody>
          {result.winners.map((w, i) => (
            <tr key={w.pid} style={{ borderBottom:'1px dashed #e8dfc8' }}>
              <td style={td}>{i+1}</td>
              <td style={{ ...td, fontWeight:600 }}><span style={{ marginLeft:8 }}>{w.emoji}</span>{w.name}</td>
              <td style={td}>{w.qty}</td>
              <td style={td}>₪{w.price.toFixed(2)}</td>
              <td style={td}>₪{w.cost.toFixed(2)}</td>
              <td style={td}><b>{w.score.toFixed(1)}</b></td>
            </tr>
          ))}
        </tbody>
        <tfoot>
          <tr style={{ borderTop:'2px solid #1a1a1a' }}>
            <td colSpan={4} style={{ ...td, fontWeight:700, textAlign:'left' }}>סה"כ</td>
            <td style={{ ...td, fontWeight:800, fontSize:16 }}>₪{total.toFixed(2)}</td>
            <td></td>
          </tr>
        </tfoot>
      </table>
      {result.ranked.filter(r => !result.winners.find(w => w.pid === r.pid)).length > 0 && (
        <div style={{ marginTop:12, fontSize:12, color:'#998877' }}>
          <b>לא נכנסו לסל:</b> {result.ranked.filter(r => !result.winners.find(w => w.pid === r.pid)).slice(0,5).map(r => r.name).join(' · ')}
        </div>
      )}
    </Card>
  );
}

// ---- Compare panel ----
function ComparePanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const [basket, setBasket] = useState('a');
  const submitted = config.coordinators.filter(c => VOTES[c.id]);
  const productsWithVotes = config.products.filter(p =>
    submitted.some(c => (VOTES[c.id][basket] || {})[p.id])
  );

  function exportCompare() {
    const header = ['מוצר', ...submitted.map(c => c.name)];
    const rows = [header];
    for (const p of productsWithVotes) {
      rows.push([p.name, ...submitted.map(c => (VOTES[c.id][basket] || {})[p.id] || '')]);
    }
    downloadCSV(rows, `השוואת-רכזים-${basket}.csv`);
  }

  return (
    <div>
      <SectionHeader title="טבלת השוואה" subtitle="מה כל רכז בחר בכל סל" />
      <div style={{ display:'flex', gap:8, marginBottom:16, flexWrap:'wrap', alignItems:'center' }}>
        {config.baskets.map(b => (
          <button key={b.id} onClick={() => setBasket(b.id)} style={{
            padding:'8px 14px', background: basket === b.id ? 'var(--accent)' : 'white',
            color: basket === b.id ? 'white' : '#1a1a1a',
            border:'2px solid #1a1a1a', borderRadius:4,
            cursor:'pointer', fontFamily:'inherit', fontWeight:700, fontSize:13,
          }}>{b.name}</button>
        ))}
        <button onClick={exportCompare} style={{ ...smallBtnStyle, marginRight:'auto' }}>📥 ייצוא CSV</button>
      </div>
      <Card>
        <div style={{ overflow:'auto', maxHeight:'70vh' }}>
          <table style={{ width:'100%', borderCollapse:'collapse', fontSize:13 }}>
            <thead style={{ position:'sticky', top:0, background:'white', zIndex:1 }}>
              <tr style={{ borderBottom:'2px solid #1a1a1a' }}>
                <th style={{ ...th, textAlign:'right', position:'sticky', right:0, background:'white', minWidth:160 }}>מוצר</th>
                {submitted.map(c => (
                  <th key={c.id} style={{ ...th, minWidth:80, textAlign:'center' }}>
                    <div style={{ fontWeight:700 }}>{c.name.split(' ')[0]}</div>
                    <div style={{ fontSize:10, color:'#998877', fontWeight:400 }}>{c.branch} · {c.weight}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {productsWithVotes.map(p => (
                <tr key={p.id} style={{ borderBottom:'1px dashed #e8dfc8' }}>
                  <td style={{ ...td, fontWeight:600, position:'sticky', right:0, background:'white' }}>
                    <span style={{ marginLeft:6 }}>{p.emoji}</span>{p.name}
                  </td>
                  {submitted.map(c => {
                    const q = (VOTES[c.id][basket] || {})[p.id];
                    return (
                      <td key={c.id} style={{ ...td, textAlign:'center' }}>
                        {q ? (
                          <div style={{ display:'inline-block', minWidth:28, padding:'2px 8px', background:'var(--accent)', color:'white', borderRadius:4, fontWeight:700 }}>{q}</div>
                        ) : (
                          <span style={{ color:'#d4c8b0' }}>·</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ---- Export panel ----
function ExportPanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const results = useMemo(() => computeWeightedResults(VOTES, config), [VOTES, config]);
  const allWinners = config.baskets.flatMap(b => results[b.id].winners.map(w => ({ ...w, basket: b.name })));
  const shopping = {};
  for (const w of allWinners) {
    if (!shopping[w.pid]) shopping[w.pid] = { ...w, qty: 0, cost: 0, baskets: [] };
    shopping[w.pid].qty  += w.qty;
    shopping[w.pid].cost += w.cost;
    shopping[w.pid].baskets.push(w.basket);
  }
  const list = Object.values(shopping).sort((a, b) => b.cost - a.cost);
  const grandTotal = list.reduce((s, x) => s + x.cost, 0);

  function doDownload() {
    const rows = [['מוצר','כמות סה"כ','מחיר ליחידה','סה"כ','סלים']];
    for (const x of list) rows.push([x.name, x.qty, x.price.toFixed(2), x.cost.toFixed(2), x.baskets.join(' + ')]);
    rows.push(['','','',grandTotal.toFixed(2),'']);
    downloadCSV(rows, 'רשימת-קניות-שכן-טוב.csv');
  }

  return (
    <div>
      <SectionHeader title="ייצוא לספק" subtitle="רשימת קניות מאוחדת לכלל הסלים שנבחרו" />
      <div style={{ display:'flex', gap:8, marginBottom:16, flexWrap:'wrap' }}>
        <button onClick={doDownload} style={primaryBtnStyle}>📥 הורד CSV / אקסל</button>
        <button onClick={() => window.print()} style={smallBtnStyle}>🖨️ הדפסה</button>
      </div>
      <Card title={`רשימת קניות · ${list.length} מוצרים · ₪${grandTotal.toFixed(2)}`}>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
          <thead>
            <tr style={{ borderBottom:'2px solid #1a1a1a', textAlign:'right' }}>
              <th style={th}>מוצר</th><th style={th}>כמות</th><th style={th}>מחיר ליח'</th><th style={th}>סה"כ</th><th style={th}>בסלים</th>
            </tr>
          </thead>
          <tbody>
            {list.map(x => (
              <tr key={x.pid} style={{ borderBottom:'1px dashed #e8dfc8' }}>
                <td style={{ ...td, fontWeight:600 }}><span style={{ marginLeft:8 }}>{x.emoji}</span>{x.name}</td>
                <td style={td}>{x.qty}</td>
                <td style={td}>₪{x.price.toFixed(2)}</td>
                <td style={{ ...td, fontWeight:700 }}>₪{x.cost.toFixed(2)}</td>
                <td style={{ ...td, fontSize:12, color:'#6b5d4d' }}>{x.baskets.join(' + ')}</td>
              </tr>
            ))}
            <tr style={{ borderTop:'2px solid #1a1a1a' }}>
              <td colSpan={3} style={{ ...td, textAlign:'left', fontWeight:700 }}>סה"כ</td>
              <td style={{ ...td, fontWeight:800, fontSize:16 }}>₪{grandTotal.toFixed(2)}</td>
              <td></td>
            </tr>
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ---- Catalog panel ----
function CatalogPanel() {
  const config = React.useContext(ConfigContext);
  const [products, setProducts] = useState(() => config.products.map(p => ({...p})));
  const [editing, setEditing]   = useState(null);
  const [adding, setAdding]     = useState(false);
  const [saving, setSaving]     = useState(false);
  const [dirty, setDirty]       = useState(false);

  function update(id, field, val) {
    setProducts(ps => ps.map(p => p.id === id ? { ...p, [field]: val } : p));
    setDirty(true);
  }
  function remove(id) {
    if (!confirm('להסיר מוצר זה מהקטלוג?')) return;
    setProducts(ps => ps.filter(p => p.id !== id));
    setDirty(true);
  }
  function add(newP) {
    setProducts(ps => [...ps, { ...newP, id: 'p-' + Date.now() }]);
    setAdding(false);
    setDirty(true);
  }
  async function handleSave() {
    setSaving(true);
    await config.saveConfig({ ...config, products });
    setSaving(false);
    setDirty(false);
    alert('✅ הקטלוג נשמר ויתעדכן אצל הרכזים!');
  }

  return (
    <div>
      <SectionHeader title="ניהול קטלוג מוצרים" subtitle={`${products.length} מוצרים פעילים`} />
      <div style={{ marginBottom:16, display:'flex', gap:8, alignItems:'center' }}>
        <button onClick={() => setAdding(true)} style={primaryBtnStyle}>+ הוסף מוצר</button>
        {dirty && (
          <button onClick={handleSave} disabled={saving} style={{ ...primaryBtnStyle, background:'#1B5E3F' }}>
            {saving ? '⏳ שומר...' : '💾 שמור שינויים'}
          </button>
        )}
        {dirty && <span style={{ fontSize:13, color:'#C81D11', fontWeight:600 }}>• יש שינויים שלא נשמרו</span>}
      </div>
      {adding && <NewProductForm onSave={add} onCancel={() => setAdding(false)} />}
      <Card>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
          <thead>
            <tr style={{ borderBottom:'2px solid #1a1a1a', textAlign:'right' }}>
              <th style={th}>אייקון</th><th style={th}>שם</th><th style={th}>קטגוריה</th>
              <th style={th}>מחיר (₪)</th><th style={th}>מקס' כמות</th><th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {products.map(p => {
              const isEditing = editing === p.id;
              return (
                <tr key={p.id} style={{ borderBottom:'1px dashed #e8dfc8' }}>
                  <td style={td}>
                    {isEditing
                      ? <input value={p.emoji} onChange={e => update(p.id, 'emoji', e.target.value)} style={{ ...inputStyle, width:50, textAlign:'center', fontSize:20 }} />
                      : <span style={{ fontSize:22 }}>{p.emoji}</span>}
                  </td>
                  <td style={{ ...td, fontWeight:600 }}>
                    {isEditing
                      ? <input value={p.name} onChange={e => update(p.id, 'name', e.target.value)} style={inputStyle} />
                      : p.name}
                  </td>
                  <td style={td}>
                    {isEditing
                      ? <select value={p.cat} onChange={e => update(p.id, 'cat', e.target.value)} style={inputStyle}>
                          <option value="dry">יבש</option><option value="fresh">טרי</option>
                        </select>
                      : <span style={{ padding:'2px 8px', borderRadius:999, fontSize:12, fontWeight:600, background: p.cat === 'fresh' ? '#E8F5E9' : '#F5EFE0', color: p.cat === 'fresh' ? '#1B5E3F' : '#998877' }}>
                          {p.cat === 'fresh' ? 'טרי' : 'יבש'}
                        </span>}
                  </td>
                  <td style={td}>
                    {isEditing
                      ? <input type="number" step="0.01" value={p.price} onChange={e => update(p.id, 'price', parseFloat(e.target.value))} style={{ ...inputStyle, width:80 }} />
                      : `₪${p.price.toFixed(2)}`}
                  </td>
                  <td style={td}>
                    {isEditing
                      ? <input type="number" value={p.max} onChange={e => update(p.id, 'max', parseInt(e.target.value))} style={{ ...inputStyle, width:70 }} />
                      : p.max}
                  </td>
                  <td style={{ ...td, textAlign:'left' }}>
                    {isEditing
                      ? <button onClick={() => setEditing(null)} style={smallBtnStyle}>שמור ✓</button>
                      : <div style={{ display:'flex', gap:4 }}>
                          <button onClick={() => setEditing(p.id)} style={smallBtnStyle}>ערוך</button>
                          <button onClick={() => remove(p.id)} style={{ ...smallBtnStyle, color:'#C81D11' }}>הסר</button>
                        </div>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

function NewProductForm({ onSave, onCancel }) {
  const [p, setP] = useState({ name:'', emoji:'🍽️', cat:'dry', price:5, max:10 });
  return (
    <div style={{ background:'#FFF8EC', border:'2px solid var(--accent)', borderRadius:6, padding:16, marginBottom:16, display:'flex', gap:8, alignItems:'flex-end', flexWrap:'wrap' }}>
      <Field label="אייקון"><input value={p.emoji} onChange={e => setP({ ...p, emoji: e.target.value })} style={{ ...inputStyle, width:60, textAlign:'center', fontSize:20 }} /></Field>
      <Field label="שם המוצר" grow><input value={p.name} onChange={e => setP({ ...p, name: e.target.value })} style={inputStyle} /></Field>
      <Field label="קטגוריה"><select value={p.cat} onChange={e => setP({ ...p, cat: e.target.value })} style={inputStyle}><option value="dry">יבש</option><option value="fresh">טרי</option></select></Field>
      <Field label="מחיר"><input type="number" step="0.01" value={p.price} onChange={e => setP({ ...p, price: parseFloat(e.target.value) || 0 })} style={{ ...inputStyle, width:90 }} /></Field>
      <Field label="מקס'"><input type="number" value={p.max} onChange={e => setP({ ...p, max: parseInt(e.target.value) || 1 })} style={{ ...inputStyle, width:70 }} /></Field>
      <button onClick={() => p.name && onSave(p)} style={primaryBtnStyle}>הוסף</button>
      <button onClick={onCancel} style={smallBtnStyle}>ביטול</button>
    </div>
  );
}

// ---- Coords panel ----
function CoordsPanel() {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const [coords, setCoords] = useState(() => config.coordinators.map(c => ({...c})));
  const [editing, setEditing] = useState(null);
  const [adding, setAdding]   = useState(false);
  const [draft, setDraft]     = useState({});
  const [saving, setSaving]   = useState(false);
  const [dirty, setDirty]     = useState(false);

  const branches = [...new Set(config.coordinators.map(c => c.branch))];

  function startEdit(c) { setEditing(c.id); setDraft({ ...c }); setAdding(false); }
  function saveEdit()   { setCoords(cs => cs.map(c => c.id === editing ? { ...draft } : c)); setEditing(null); setDirty(true); }
  function startAdd()   { setAdding(true); setEditing(null); setDraft({ name:'', branch: branches[0] || '', weight:1 }); }
  function saveAdd()    {
    if (!draft.name || !draft.branch) return alert('יש למלא שם וסניף');
    setCoords(cs => [...cs, { ...draft, id: 'c-' + Date.now() }]);
    setAdding(false);
    setDirty(true);
  }
  function removeCoord(id) {
    if (!confirm('להסיר רכז זה?')) return;
    setCoords(cs => cs.filter(c => c.id !== id));
    setDirty(true);
  }
  async function handleSave() {
    setSaving(true);
    await config.saveConfig({ ...config, coordinators: coords });
    setSaving(false);
    setDirty(false);
    alert('✅ רשימת הרכזים נשמרה ותתעדכן אצל כולם!');
  }

  return (
    <div>
      <SectionHeader title="ניהול רכזים" subtitle={`${coords.length} רכזים · ${coords.reduce((s,c) => s+c.weight,0).toFixed(1)} סה"כ משקל`} />
      <div style={{ marginBottom:16, display:'flex', gap:8, alignItems:'center' }}>
        <button onClick={startAdd} style={primaryBtnStyle}>+ הוסף רכז</button>
        {dirty && (
          <button onClick={handleSave} disabled={saving} style={{ ...primaryBtnStyle, background:'#1B5E3F' }}>
            {saving ? '⏳ שומר...' : '💾 שמור שינויים'}
          </button>
        )}
        {dirty && <span style={{ fontSize:13, color:'#C81D11', fontWeight:600 }}>• יש שינויים שלא נשמרו</span>}
      </div>
      {adding && (
        <div style={{ background:'#FFF8EC', border:'2px solid var(--accent)', borderRadius:6, padding:16, marginBottom:16, display:'flex', gap:8, alignItems:'flex-end', flexWrap:'wrap' }}>
          <Field label="שם מלא" grow><input value={draft.name} onChange={e => setDraft(d => ({ ...d, name: e.target.value }))} style={inputStyle} autoFocus /></Field>
          <Field label="סניף">
            <select value={draft.branch} onChange={e => setDraft(d => ({ ...d, branch: e.target.value }))} style={inputStyle}>
              {branches.map(b => <option key={b} value={b}>{b}</option>)}
            </select>
          </Field>
          <Field label="משקל">
            <select value={draft.weight} onChange={e => setDraft(d => ({ ...d, weight: parseFloat(e.target.value) }))} style={{ ...inputStyle, width:80 }}>
              <option value="1">1.0</option><option value="0.5">0.5</option>
            </select>
          </Field>
          <button onClick={saveAdd} style={primaryBtnStyle}>הוסף ✓</button>
          <button onClick={() => setAdding(false)} style={smallBtnStyle}>ביטול</button>
        </div>
      )}
      <Card>
        <table style={{ width:'100%', borderCollapse:'collapse', fontSize:14 }}>
          <thead>
            <tr style={{ borderBottom:'2px solid #1a1a1a', textAlign:'right' }}>
              <th style={th}>שם</th><th style={th}>סניף</th><th style={th}>משקל</th><th style={th}>סטטוס</th><th style={th}></th>
            </tr>
          </thead>
          <tbody>
            {coords.map(c => {
              const voted = !!VOTES[c.id];
              const isEditing = editing === c.id;
              return (
                <tr key={c.id} style={{ borderBottom:'1px dashed #e8dfc8', background: isEditing ? '#FFF8EC' : 'transparent' }}>
                  <td style={{ ...td, fontWeight:600 }}>
                    {isEditing ? <input value={draft.name} onChange={e => setDraft(d => ({ ...d, name: e.target.value }))} style={{ ...inputStyle, width:'100%' }} autoFocus /> : c.name}
                  </td>
                  <td style={td}>
                    {isEditing ? <select value={draft.branch} onChange={e => setDraft(d => ({ ...d, branch: e.target.value }))} style={inputStyle}>{branches.map(b => <option key={b} value={b}>{b}</option>)}</select> : c.branch}
                  </td>
                  <td style={td}>
                    <select value={isEditing ? draft.weight : c.weight}
                      onChange={e => {
                        const w = parseFloat(e.target.value);
                        if (isEditing) setDraft(d => ({ ...d, weight: w }));
                        else { setCoords(cs => cs.map(x => x.id === c.id ? { ...x, weight: w } : x)); setDirty(true); }
                      }}
                      style={{ ...inputStyle, width:80 }}>
                      <option value="1">1.0</option><option value="0.5">0.5</option>
                    </select>
                  </td>
                  <td style={td}>
                    {voted ? <span style={{ color:'#1B5E3F', fontWeight:700 }}>✓ הצביע</span> : <span style={{ color:'#8A6500' }}>… ממתין</span>}
                  </td>
                  <td style={{ ...td, textAlign:'left' }}>
                    {isEditing
                      ? <div style={{ display:'flex', gap:4 }}>
                          <button onClick={saveEdit} style={{ ...smallBtnStyle, color:'#1B5E3F', borderColor:'#1B5E3F' }}>שמור ✓</button>
                          <button onClick={() => setEditing(null)} style={smallBtnStyle}>ביטול</button>
                        </div>
                      : <div style={{ display:'flex', gap:4 }}>
                          <button onClick={() => startEdit(c)} style={smallBtnStyle}>ערוך</button>
                          <button onClick={() => removeCoord(c.id)} style={{ ...smallBtnStyle, color:'#C81D11' }}>הסר</button>
                        </div>}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </div>
  );
}

// ---- Rounds panel ----
function RoundsPanel({ roundNum, roundOpen, roundOpenedAt, onReset, onNewRound, onToggleClose }) {
  const VOTES  = React.useContext(VotesContext);
  const config = React.useContext(ConfigContext);
  const [baskets, setBaskets] = useState(() => config.baskets.map(b => ({...b})));
  const [savingB, setSavingB] = useState(false);
  const submittedCount = config.coordinators.filter(c => VOTES[c.id]).length;
  const daysOpen = Math.floor((Date.now() - roundOpenedAt) / (24 * 60 * 60 * 1000));

  async function saveBudgets() {
    setSavingB(true);
    await config.saveConfig({ ...config, baskets });
    setSavingB(false);
    alert('✅ תקציבי הסלים עודכנו!');
  }

  return (
    <div>
      <SectionHeader title="ניהול סבבים" subtitle="פתיחה, סגירה ואיפוס סבבי הצבעה" />
      <div style={{ display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:16 }}>
        <Card title="הסבב הנוכחי">
          <div style={{ fontSize:13, color:'#6b5d4d', marginBottom:4 }}>סבב #{roundNum}</div>
          <div style={{ fontSize:16, fontWeight:700, marginBottom:4 }}>
            {roundOpen ? '🟢 פתוח' : '🔴 סגור'} · {roundOpen ? `נפתח לפני ${daysOpen} ימים` : 'ההצבעה סגורה'}
          </div>
          <div style={{ fontSize:13, color:'#6b5d4d', marginBottom:12 }}>{submittedCount} / {config.coordinators.length} רכזים הצביעו</div>
          <div style={{ display:'flex', gap:6, flexWrap:'wrap' }}>
            <button onClick={onToggleClose} style={smallBtnStyle}>{roundOpen ? '🔒 סגור הצבעה' : '🔓 פתח מחדש'}</button>
            <button onClick={onReset} style={{ ...smallBtnStyle, color:'#C81D11', borderColor:'#C81D11' }}>↺ איפוס סבב</button>
          </div>
        </Card>
        <Card title="פתח סבב חדש">
          <div style={{ fontSize:13, color:'#6b5d4d', marginBottom:12 }}>פעולה זו תנקה את הצבעות הסבב הקודם ותעבור לסבב הבא.</div>
          <button onClick={onNewRound} style={primaryBtnStyle}>+ סבב חדש (#{roundNum + 1})</button>
        </Card>
        <Card title="הגדרות תקציב סלים" accent>
          <div style={{ fontSize:13, color:'#6b5d4d', marginBottom:12 }}>שינוי תקציב הסלים — יישמר לכל הרכזים.</div>
          <div style={{ display:'flex', flexDirection:'column', gap:8, marginBottom:12 }}>
            {baskets.map((b, i) => (
              <div key={b.id} style={{ display:'flex', alignItems:'center', gap:8 }}>
                <div style={{ flex:1, fontSize:14, fontWeight:600 }}>{b.name}</div>
                <span style={{ color:'#998877' }}>₪</span>
                <input type="number" value={b.budget}
                  onChange={e => setBaskets(bs => bs.map((x, j) => j === i ? { ...x, budget: parseFloat(e.target.value) || 0 } : x))}
                  style={{ ...inputStyle, width:80 }} />
              </div>
            ))}
          </div>
          <button onClick={saveBudgets} disabled={savingB} style={primaryBtnStyle}>
            {savingB ? '⏳ שומר...' : '💾 שמור תקציבים'}
          </button>
        </Card>
      </div>
    </div>
  );
}

// ---- Shared UI ----
function SectionHeader({ title, subtitle }) {
  return (
    <div style={{ marginBottom:20 }}>
      <h2 style={{ fontSize:26, fontWeight:800, margin:'0 0 4px', letterSpacing:'-0.02em' }}>{title}</h2>
      {subtitle && <p style={{ margin:0, color:'#6b5d4d', fontSize:15 }}>{subtitle}</p>}
    </div>
  );
}
function Card({ title, accent, children }) {
  return (
    <div style={{ background:'white', border:'2px solid #1a1a1a', borderRadius:6, boxShadow: accent ? '5px 5px 0 var(--accent)' : '4px 4px 0 #1a1a1a', padding:16, marginBottom:0 }}>
      {title && <div style={{ fontSize:14, fontWeight:800, marginBottom:12, paddingBottom:8, borderBottom:'1px solid #e8dfc8', letterSpacing:'-0.01em' }}>{title}</div>}
      {children}
    </div>
  );
}
function Stat({ label, value, accent }) {
  return (
    <div style={{ background: accent ? 'var(--accent)' : 'white', color: accent ? 'white' : '#1a1a1a', border:'2px solid #1a1a1a', borderRadius:6, padding:'14px 16px', boxShadow:'3px 3px 0 #1a1a1a' }}>
      <div style={{ fontSize:12, opacity:0.7, fontWeight:600, marginBottom:4 }}>{label}</div>
      <div style={{ fontSize:22, fontWeight:800 }}>{value}</div>
    </div>
  );
}
function BudgetBar({ used, budget }) {
  const pct = Math.min(100, (used / budget) * 100);
  return (
    <div>
      <div style={{ display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:4 }}>
        <span style={{ fontWeight:600 }}>₪{used.toFixed(2)} מתוך ₪{budget}</span>
        <span style={{ color:'#998877' }}>{pct.toFixed(0)}%</span>
      </div>
      <div style={{ height:8, background:'#F5EFE0', borderRadius:999, overflow:'hidden', border:'1px solid #1a1a1a' }}>
        <div style={{ width: pct + '%', height:'100%', background:'var(--accent)' }} />
      </div>
    </div>
  );
}
function Field({ label, grow, children }) {
  return (
    <label style={{ display:'flex', flexDirection:'column', gap:4, flex: grow ? 1 : '0 0 auto', minWidth:100 }}>
      <span style={{ fontSize:11, fontWeight:700, color:'#6b5d4d' }}>{label}</span>
      {children}
    </label>
  );
}

const inputStyle    = { padding:'6px 8px', border:'1.5px solid #1a1a1a', borderRadius:4, fontFamily:'inherit', fontSize:14, background:'white' };
const smallBtnStyle = { padding:'6px 12px', border:'1.5px solid #1a1a1a', borderRadius:4, background:'white', fontFamily:'inherit', fontSize:13, fontWeight:600, cursor:'pointer', color:'#1a1a1a' };
const primaryBtnStyle = { padding:'8px 14px', border:'2px solid #1a1a1a', borderRadius:4, background:'var(--accent)', color:'white', fontFamily:'inherit', fontSize:14, fontWeight:700, cursor:'pointer', boxShadow:'3px 3px 0 #1a1a1a' };
const th = { padding:'8px 6px', fontSize:12, fontWeight:700, color:'#6b5d4d', letterSpacing:'0.04em', textTransform:'uppercase' };
const td = { padding:'10px 6px', verticalAlign:'middle' };

ReactDOM.createRoot(document.getElementById('root')).render(<AdminApp />);
