// Shared hooks and helpers for all variations
const { useState, useEffect, useMemo, useRef } = React;

// Persistent state per coordinator + variant
function useCoordinatorState(variant) {
  const KEY = `shachen-tov-${variant}`;
  const [state, setState] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem(KEY)) || {};
    } catch { return {}; }
  });
  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(state));
  }, [state]);
  return [state, setState];
}

function basketTotal(items, products) {
  return Object.entries(items || {}).reduce((sum, [pid, qty]) => {
    const p = products.find(x => x.id === pid);
    return p ? sum + p.price * qty : sum;
  }, 0);
}

function fmtPrice(n) {
  return '₪' + n.toFixed(2).replace(/\.00$/, '');
}

async function loadLiveConfig() {
  if (!window.db) return null;
  try {
    const doc = await window.db.collection('config').doc('main').get();
    return doc.exists ? doc.data() : null;
  } catch { return null; }
}

function getVisibleProducts(branch, overrideProducts) {
  const products = overrideProducts || window.APP_DATA.products;
  const freshExcluded = window.APP_DATA.freshExcluded;
  const excluded = freshExcluded.includes(branch);
  return products.filter(p => !(excluded && p.id === 'veg'));
}

// Get basket completion status
function basketStatus(items, basket, products) {
  const total = basketTotal(items, products);
  const pct = (total / basket.budget) * 100;
  if (pct === 0) return { state: 'empty', pct, total };
  if (pct > 100) return { state: 'over', pct, total };
  if (pct >= 90) return { state: 'warn', pct, total };
  return { state: 'ok', pct, total };
}

// Coordinator picker — loads live config from Firebase if available
function CoordinatorPicker({ onPick, accent = '#E94E1B' }) {
  const [liveConfig, setLiveConfig] = React.useState(null);
  React.useEffect(() => {
    if (window.db) {
      window.db.collection('config').doc('main').get()
        .then(doc => { if (doc.exists) setLiveConfig(doc.data()); })
        .catch(() => {});
    }
  }, []);
  const cfg    = liveConfig || window.APP_DATA;
  const coords = cfg.coordinators;
  const branches = [...new Set(coords.map(c => c.branch))];

  return (
    <div style={{
      minHeight: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: '32px 20px', direction: 'rtl', position: 'relative',
    }}>
      <a href="admin.html" style={{
        position: 'absolute', top: 16, left: 16,
        padding: '8px 14px', background: '#1a1a1a', color: 'white',
        textDecoration: 'none', fontSize: 12, fontWeight: 700, borderRadius: 4,
        border: '2px solid #1a1a1a', letterSpacing: '0.05em',
      }}>לוח אדמין ←</a>
      <div style={{ maxWidth: 720, width: '100%' }}>
        <div style={{ marginBottom: 32, textAlign: 'center' }}>
          <div style={{
            display: 'inline-block', padding: '6px 14px', background: accent,
            color: 'white', fontSize: 13, fontWeight: 600, borderRadius: 999,
            marginBottom: 12, letterSpacing: '0.05em',
          }}>שכן טוב · ירושלים</div>
          <h1 style={{
            fontSize: 'clamp(28px, 5vw, 44px)', margin: '0 0 8px', fontWeight: 800,
            letterSpacing: '-0.02em', lineHeight: 1.1,
          }}>שלום, איזה רכז את/ה?</h1>
          <p style={{ fontSize: 16, color: '#6b5d4d', margin: 0 }}>
            בחר/י את שמך כדי להתחיל לבנות את הסלים לסבב הנוכחי.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
          {branches.map(branch => (
            <div key={branch}>
              <div style={{
                fontSize: 12, fontWeight: 700, color: '#998877',
                marginBottom: 8, letterSpacing: '0.08em',
              }}>סניף {branch.toUpperCase()}</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                {coords.filter(c => c.branch === branch).map(c => (
                  <button
                    key={c.id}
                    onClick={() => onPick(c)}
                    style={{
                      flex: '1 1 auto', minWidth: 160, textAlign: 'right',
                      padding: '14px 16px', background: 'white',
                      border: '2px solid #1a1a1a', borderRadius: 4,
                      cursor: 'pointer', fontFamily: 'inherit',
                      fontSize: 15, fontWeight: 600, color: '#1a1a1a',
                      transition: 'all 0.12s',
                      boxShadow: '3px 3px 0 #1a1a1a',
                    }}
                    onMouseEnter={e => {
                      e.currentTarget.style.transform = 'translate(-2px, -2px)';
                      e.currentTarget.style.boxShadow = '5px 5px 0 ' + accent;
                    }}
                    onMouseLeave={e => {
                      e.currentTarget.style.transform = '';
                      e.currentTarget.style.boxShadow = '3px 3px 0 #1a1a1a';
                    }}
                  >
                    <div>{c.name}</div>
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  useCoordinatorState, basketTotal, fmtPrice,
  getVisibleProducts, basketStatus, CoordinatorPicker,
});
