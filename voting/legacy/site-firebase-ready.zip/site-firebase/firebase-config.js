// הגדרות Firebase — שכן טוב
const FIREBASE_CONFIG = {
  apiKey:            "AIzaSyCvYBb-abDO0EcyW7rpVyK1RQQoAKdlJX0",
  authDomain:        "shachentov-1316f.firebaseapp.com",
  projectId:         "shachentov-1316f",
  storageBucket:     "shachentov-1316f.firebasestorage.app",
  messagingSenderId: "751389452970",
  appId:             "1:751389452970:web:547c8a1be8f36d1ab3bed3",
};

// אתחול Firebase
firebase.initializeApp(FIREBASE_CONFIG);
window.db = firebase.firestore();
