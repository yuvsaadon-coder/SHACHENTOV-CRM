// Variation 3: Marketplace / dense list view — list rows with inline qty and category sidebar
function VariantMarket({ coordinator, onLogout, accent }) {
  const [state, setState] = useCoordinatorState(`v3-${coordinator.id}`);
  const [activeBasket, setActiveBasket] = React.useState('a');
  const [activeCat, setActiveCat] = React.useState('all');
  const baskets = window.APP_DATA.baskets;
  const products = React.useMemo(() => getVisibleProducts(coordinator.branch), [coordinator.branch]);

  const isUnlocked = (idx) => {
    if (idx === 0) return true;
    for (let i = 0; i < idx; i++) {
      const t = basketTotal(state[baskets[i].id] || {}, products);
      if (t === 0 || t > baskets[i].budget) return false;
    }
    return true;
  };

  const allValid = baskets.every(b => {
    const t = basketTotal(state[b.id] || {}, products);
    return t > 0 && t <= b.budget;
  });

  const items = state[activeBasket] || {};
  const basket = baskets.find(b => b.id === activeBasket);
  const status = basketStatus(items, basket, products);

  const setQty = (pid, qty) => {
    const p = products.find(x => x.id === pid);
    if (!p) return;
    qty = Math.max(0, Math.min(qty, p.max));
    setState(s => ({ ...s, [activeBasket]: { ...(s[activeBasket] || {}), [pid]: qty } }));
  };

  const submit = () => {
    if (!allValid) return;
    setState(s => ({ ...s, _submitted: true, _submittedAt: Date.now() }));
    alert('ההצבעה נשלחה בהצלחה!');
  };

  const cats = [
    { id: 'all', label: 'הכל', icon: '🛒' },
    { id: 'dry', label: 'יבש', icon: '🥫' },
    ...(getVisibleProducts(coordinator.branch).some(p => p.cat === 'fresh') ? [{ id: 'fresh', label: 'טרי', icon: '🥬' }] : []),
  ];
  const filtered = activeCat === 'all' ? products : products.filter(p => p.cat === activeCat);
  const selectedItems = Object.entries(items).filter(([_, q]) => q > 0);

  const c = status.state === 'over' ? '#C81D11' : status.state === 'warn' ? '#D88F00' : status.state === 'ok' ? '#1B5E3F' : '#998877';

  return (
    <div style={{ minHeight: '100%', direction: 'rtl', paddingBottom: 110, background: 'var(--bg, #FFF8EC)' }}>
      <header style={{
        background: 'white', borderBottom: '2px solid #1a1a1a',
        padding: '12px 18px', display: 'flex', alignItems: 'center', gap: 12,
        position: 'sticky', top: 0, zIndex: 5,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: '#998877', fontWeight: 600 }}>שכן טוב · {coordinator.branch}</div>
          <div style={{ fontSize: 15, fontWeight: 700 }}>{coordinator.name}</div>
        </div>
        <button onClick={onLogout} style={{
          background: 'none', border: '1.5px solid #1a1a1a', borderRadius: 4,
          padding: '5px 10px', fontFamily: 'inherit', fontSize: 12, cursor: 'pointer',
        }}>החלף</button>
      </header>

      {/* Basket pills */}
      <div style={{ padding: '12px 18px', display: 'flex', gap: 8, overflowX: 'auto', background: 'white', borderBottom: '1.5px solid #1a1a1a' }}>
        {baskets.map((b, i) => {
          const unlocked = isUnlocked(i);
          const active = activeBasket === b.id;
          const t = basketTotal(state[b.id] || {}, products);
          const valid = t > 0 && t <= b.budget;
          return (
            <button key={b.id} disabled={!unlocked}
              onClick={() => unlocked && setActiveBasket(b.id)}
              style={{
                flex: '0 0 auto', padding: '8px 14px',
                background: active ? '#1a1a1a' : 'white',
                color: active ? 'white' : '#1a1a1a',
                border: '1.5px solid #1a1a1a', borderRadius: 999,
                fontFamily: 'inherit', fontSize: 13, fontWeight: 700,
                cursor: unlocked ? 'pointer' : 'not-allowed',
                opacity: unlocked ? 1 : 0.4,
                whiteSpace: 'nowrap', display: 'flex', alignItems: 'center', gap: 6,
              }}>
              {!unlocked && '🔒 '}{b.name}
              {valid && <span style={{ color: active ? accent : '#1B5E3F' }}>✓</span>}
            </button>
          );
        })}
      </div>

      <div style={{ display: 'flex', gap: 0 }}>
        {/* Category sidebar */}
        <aside style={{
          width: 80, flexShrink: 0, background: '#1a1a1a', color: 'white',
          minHeight: 'calc(100vh - 220px)', padding: '12px 0',
          display: 'flex', flexDirection: 'column', gap: 4,
          position: 'sticky', top: 110, alignSelf: 'flex-start',
        }}>
          {cats.map(cat => (
            <button key={cat.id} onClick={() => setActiveCat(cat.id)}
              style={{
                background: activeCat === cat.id ? accent : 'transparent',
                color: 'white', border: 'none', padding: '14px 4px',
                fontFamily: 'inherit', cursor: 'pointer', fontSize: 11, fontWeight: 700,
                display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
                borderRight: activeCat === cat.id ? `4px solid white` : '4px solid transparent',
              }}>
              <span style={{ fontSize: 22 }}>{cat.icon}</span>
              <span>{cat.label}</span>
            </button>
          ))}
        </aside>

        {/* Product list */}
        <main style={{ flex: 1, minWidth: 0, padding: '12px 14px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            {filtered.map(p => {
              const qty = items[p.id] || 0;
              return (
                <div key={p.id} style={{
                  background: 'white', border: '1.5px solid #1a1a1a', borderRadius: 4,
                  padding: '10px 12px', display: 'flex', alignItems: 'center', gap: 12,
                  borderRight: qty > 0 ? `5px solid ${accent}` : '1.5px solid #1a1a1a',
                }}>
                  <div style={{ fontSize: 32 }}>{p.emoji}</div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 14, fontWeight: 700 }}>{p.name}</div>
                    <div style={{ fontSize: 11, color: '#998877' }}>
                      {fmtPrice(p.price)}{p.max < 10 ? ` · מקס ${p.max}` : ''}
                      {qty > 0 && <span style={{ color: accent, fontWeight: 700 }}> · {fmtPrice(qty * p.price)}</span>}
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 0, border: '1.5px solid #1a1a1a', borderRadius: 4 }}>
                    <button onClick={() => setQty(p.id, qty - 1)} disabled={qty === 0}
                      style={{ width: 32, height: 32, border: 'none', borderLeft: '1px solid #1a1a1a',
                        background: 'white', cursor: qty === 0 ? 'not-allowed' : 'pointer',
                        fontFamily: 'inherit', fontSize: 16, fontWeight: 700, opacity: qty === 0 ? 0.4 : 1 }}>−</button>
                    <div style={{ width: 36, height: 32, display: 'grid', placeItems: 'center',
                      background: qty > 0 ? accent : 'white', color: qty > 0 ? 'white' : '#1a1a1a',
                      borderLeft: '1px solid #1a1a1a', fontWeight: 800, fontSize: 14 }}>{qty}</div>
                    <button onClick={() => setQty(p.id, qty + 1)} disabled={qty >= p.max}
                      style={{ width: 32, height: 32, border: 'none',
                        background: 'white', cursor: qty >= p.max ? 'not-allowed' : 'pointer',
                        fontFamily: 'inherit', fontSize: 16, fontWeight: 700, opacity: qty >= p.max ? 0.4 : 1 }}>+</button>
                  </div>
                </div>
              );
            })}
          </div>

          {selectedItems.length > 0 && (
            <div style={{ marginTop: 16, padding: '12px 14px', background: 'white', border: '2px solid #1a1a1a', borderRadius: 4 }}>
              <div style={{ fontSize: 11, fontWeight: 700, color: '#998877', marginBottom: 6 }}>נבחרו ב{basket.name}:</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {selectedItems.map(([pid, q]) => {
                  const p = products.find(x => x.id === pid);
                  return (
                    <span key={pid} style={{
                      fontSize: 12, padding: '3px 8px', background: '#F5EFE0',
                      border: '1px solid #1a1a1a', borderRadius: 999, fontWeight: 600,
                    }}>{p.emoji} {p.name} ×{q}</span>
                  );
                })}
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Sticky budget bar */}
      <div style={{
        position: 'fixed', bottom: 0, right: 0, left: 0, background: 'white',
        borderTop: '2px solid #1a1a1a', padding: '10px 18px', zIndex: 10,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 6 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: '#998877', fontWeight: 600 }}>{basket.name}</div>
            <div style={{ fontSize: 17, fontWeight: 800 }}>
              <span style={{ color: c }}>{fmtPrice(status.total)}</span>
              <span style={{ color: '#998877', fontSize: 13 }}> / {fmtPrice(basket.budget)}</span>
              {status.state === 'over' && <span style={{ color: '#C81D11', fontSize: 12, marginInlineStart: 6 }}>חריגה!</span>}
              {status.state === 'warn' && <span style={{ color: '#8A6500', fontSize: 12, marginInlineStart: 6 }}>קרוב לגבול</span>}
            </div>
          </div>
          <button onClick={submit} disabled={!allValid}
            style={{ padding: '10px 18px', border: '2px solid #1a1a1a',
              background: allValid ? accent : '#f0e6d2', color: allValid ? 'white' : '#998877',
              fontFamily: 'inherit', fontWeight: 700, fontSize: 14,
              cursor: allValid ? 'pointer' : 'not-allowed', borderRadius: 4,
              boxShadow: allValid ? '3px 3px 0 #1a1a1a' : 'none' }}>
            שלח הצבעה
          </button>
        </div>
        <div style={{ height: 6, background: '#F5EFE0', border: '1px solid #1a1a1a', overflow: 'hidden' }}>
          <div style={{ height: '100%', width: Math.min(100, status.pct) + '%', background: c, transition: 'width 0.2s' }} />
        </div>
      </div>
    </div>
  );
}

window.VariantMarket = VariantMarket;
