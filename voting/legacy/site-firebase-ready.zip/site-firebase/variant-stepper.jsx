// Variation 2: Stepper/checklist style — vertical wizard with collapsible baskets
function VariantStepper({ coordinator, onLogout, accent }) {
  const [state, setState] = useCoordinatorState(`v2-${coordinator.id}`);
  const [openBasket, setOpenBasket] = React.useState('a');
  // Load live config from Firebase (falls back to data.js)
  const [liveConfig, setLiveConfig] = React.useState(null);
  React.useEffect(() => {
    if (window.db) {
      window.db.collection('config').doc('main').get()
        .then(doc => { if (doc.exists) setLiveConfig(doc.data()); })
        .catch(() => {});
    }
  }, []);
  const baskets  = (liveConfig || window.APP_DATA).baskets;
  const products = React.useMemo(
    () => getVisibleProducts(coordinator.branch, liveConfig ? liveConfig.products : null),
    [coordinator.branch, liveConfig]
  );

  const isUnlocked = (idx) => {
    if (idx === 0) return true;
    for (let i = 0; i < idx; i++) {
      const t = basketTotal(state[baskets[i].id] || {}, products);
      if (t === 0 || t > baskets[i].budget) return false;
    }
    return true;
  };

  const allValid = baskets.every(b => {
    const t = basketTotal(state[b.id] || {}, products);
    return t > 0 && t <= b.budget;
  });

  // For unlocking: previous basket only needs to NOT be over budget (under is OK)
  const isPrevDone = (idx) => {
    const t = basketTotal(state[baskets[idx].id] || {}, products);
    return t > 0 && t <= baskets[idx].budget;
  };

  const setQty = (basketId, pid, qty) => {
    const p = products.find(x => x.id === pid);
    if (!p) return;
    qty = Math.max(0, Math.min(qty, p.max));
    setState(s => ({ ...s, [basketId]: { ...(s[basketId] || {}), [pid]: qty } }));
  };

  const [submitting, setSubmitting] = React.useState(false);

  const submit = async () => {
    if (!allValid || submitting) return;
    setSubmitting(true);
    const now = Date.now();
    const voteData = {
      coordinatorId:   coordinator.id,
      coordinatorName: coordinator.name,
      branch:          coordinator.branch,
      submittedAt:     now,
    };
    for (const b of baskets) {
      voteData[b.id] = state[b.id] || {};
    }
    try {
      await window.db.collection('votes').doc(coordinator.id).set(voteData);
      setState(s => ({ ...s, _submitted: true, _submittedAt: now }));
      alert('✅ ההצבעה נשלחה ונשמרה בהצלחה! תודה ' + coordinator.name);
    } catch (err) {
      console.error('Firebase save error:', err);
      alert('❌ שגיאה בשמירה: ' + err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const totalAll = baskets.reduce((s, b) => s + basketTotal(state[b.id] || {}, products), 0);
  const budgetAll = baskets.reduce((s, b) => s + b.budget, 0);

  return (
    <div style={{ minHeight: '100%', direction: 'rtl', paddingBottom: 110, background: 'var(--bg, #FFF8EC)' }}>
      <header style={{
        background: '#1a1a1a', color: 'white',
        padding: '20px 20px 28px', position: 'relative',
      }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 12, color: accent, fontWeight: 700, marginBottom: 4, letterSpacing: '0.05em' }}>
              שכן טוב · סבב הזמנה
            </div>
            <div style={{ fontSize: 22, fontWeight: 800 }}>{coordinator.name}</div>
            <div style={{ fontSize: 13, opacity: 0.7 }}>סניף {coordinator.branch}</div>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <button onClick={onLogout} style={{
              background: 'transparent', border: '1px solid rgba(255,255,255,0.3)', color: 'white',
              padding: '6px 12px', borderRadius: 4, fontFamily: 'inherit', fontSize: 12, cursor: 'pointer',
            }}>החלף</button>
            <a href="admin.html" style={{
              background: accent, color: 'white', textDecoration: 'none',
              padding: '6px 12px', borderRadius: 4, fontSize: 12, fontWeight: 700,
              textAlign: 'center', border: '1px solid ' + accent,
            }}>אדמין ←</a>
          </div>
        </div>
        <div style={{ marginTop: 16, fontSize: 13, opacity: 0.85 }}>
          התקדמות כוללת: <strong>{fmtPrice(totalAll)}</strong> מתוך {fmtPrice(budgetAll)}
        </div>
        <div style={{ marginTop: 8, height: 6, background: 'rgba(255,255,255,0.15)', borderRadius: 3, overflow: 'hidden' }}>
          <div style={{
            width: Math.min(100, (totalAll / budgetAll) * 100) + '%',
            height: '100%', background: accent, transition: 'width 0.3s',
          }} />
        </div>
      </header>

      <div style={{ padding: '20px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {baskets.map((b, i) => {
          const items = state[b.id] || {};
          const status = basketStatus(items, b, products);
          const unlocked = isUnlocked(i);
          const open = openBasket === b.id && unlocked;
          const itemCount = Object.values(items).reduce((s, v) => s + v, 0);

          const stateChip = {
            empty: { bg: '#F5EFE0', fg: '#998877', label: 'טרם התחיל' },
            ok: { bg: '#E8F5E9', fg: '#1B5E3F', label: '✓ מוכן לשליחה' },
            warn: { bg: '#FFF4D6', fg: '#8A6500', label: '⚠ קרוב לגבול' },
            over: { bg: '#FFE5E2', fg: '#C81D11', label: '⛔ חריגה' },
          }[status.state];

          return (
            <div key={b.id} style={{
              background: 'white', border: '2px solid #1a1a1a', borderRadius: 6,
              boxShadow: '4px 4px 0 #1a1a1a', overflow: 'hidden',
              opacity: unlocked ? 1 : 0.55,
            }}>
              <button
                onClick={() => unlocked && setOpenBasket(open ? null : b.id)}
                disabled={!unlocked}
                style={{
                  width: '100%', textAlign: 'right', padding: '16px 18px',
                  background: open ? accent : 'white', color: open ? 'white' : '#1a1a1a',
                  border: 'none', cursor: unlocked ? 'pointer' : 'not-allowed',
                  fontFamily: 'inherit', display: 'flex', alignItems: 'center', gap: 14,
                  borderBottom: open ? '2px solid #1a1a1a' : 'none',
                }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%',
                  background: open ? 'white' : '#1a1a1a', color: open ? accent : 'white',
                  display: 'grid', placeItems: 'center', fontWeight: 800, fontSize: 16,
                  flexShrink: 0,
                }}>{unlocked ? i + 1 : '🔒'}</div>
                <div style={{ flex: 1, textAlign: 'right' }}>
                  <div style={{ fontSize: 16, fontWeight: 800 }}>{b.name}</div>
                  <div style={{ fontSize: 12, opacity: 0.8 }}>
                    תקציב {b.budget}₪ · {itemCount > 0 ? `${itemCount} פריטים · ${fmtPrice(status.total)}` : 'ריק'}
                  </div>
                </div>
                {!open && unlocked && (
                  <span style={{
                    fontSize: 11, fontWeight: 700, padding: '4px 10px', borderRadius: 999,
                    background: stateChip.bg, color: stateChip.fg,
                  }}>{stateChip.label}</span>
                )}
                <span style={{ fontSize: 20, fontWeight: 700 }}>{open ? '–' : '+'}</span>
              </button>

              {open && (
                <div style={{ padding: '16px 18px', background: 'var(--bg, #FFF8EC)' }}>
                  <div style={{
                    display: 'grid', gap: 10,
                    gridTemplateColumns: 'repeat(auto-fill, minmax(160px, 1fr))',
                  }}>
                    {products.map(p => {
                      const qty = items[p.id] || 0;
                      return (
                        <div key={p.id} style={{
                          background: 'white', border: '1.5px solid #1a1a1a', borderRadius: 4,
                          padding: 10, display: 'flex', flexDirection: 'column', gap: 8,
                          boxShadow: qty > 0 ? `2px 2px 0 ${accent}` : 'none',
                        }}>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                            <div style={{ fontSize: 28 }}>{p.emoji}</div>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontSize: 13, fontWeight: 700, lineHeight: 1.2 }}>{p.name}</div>
                              <div style={{ fontSize: 11, color: '#998877' }}>{fmtPrice(p.price)}{p.max < 10 ? ` · מקס ${p.max}` : ''}</div>
                            </div>
                          </div>
                          <div style={{ display: 'flex', border: '1.5px solid #1a1a1a', borderRadius: 4 }}>
                            <button onClick={() => setQty(b.id, p.id, qty - 1)} disabled={qty === 0}
                              style={{ flex: 1, padding: '6px 0', border: 'none', borderLeft: '1px solid #1a1a1a',
                                background: 'white', cursor: qty === 0 ? 'not-allowed' : 'pointer',
                                fontFamily: 'inherit', fontSize: 16, fontWeight: 700, opacity: qty === 0 ? 0.4 : 1 }}>−</button>
                            <div style={{ flex: 1, padding: '6px 0', textAlign: 'center', fontWeight: 800,
                              background: qty > 0 ? accent : 'white', color: qty > 0 ? 'white' : '#1a1a1a',
                              borderLeft: '1px solid #1a1a1a', fontSize: 14 }}>{qty}</div>
                            <button onClick={() => setQty(b.id, p.id, qty + 1)} disabled={qty >= p.max}
                              style={{ flex: 1, padding: '6px 0', border: 'none',
                                background: 'white', cursor: qty >= p.max ? 'not-allowed' : 'pointer',
                                fontFamily: 'inherit', fontSize: 16, fontWeight: 700, opacity: qty >= p.max ? 0.4 : 1 }}>+</button>
                          </div>
                        </div>
                      );
                    })}
                  </div>

                  {/* Per-basket budget summary */}
                  <div style={{
                    marginTop: 14, padding: '10px 14px',
                    background: status.state === 'over' ? '#FFE5E2' : status.state === 'warn' ? '#FFF4D6' : 'white',
                    border: '2px solid #1a1a1a', borderRadius: 4,
                    display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 10,
                  }}>
                    <div style={{ fontSize: 13 }}>
                      <strong>{fmtPrice(status.total)}</strong> / {fmtPrice(b.budget)}
                      {status.state === 'over' && <span style={{ color: '#C81D11', marginInlineStart: 8 }}>חרגת ב-{fmtPrice(status.total - b.budget)}</span>}
                      {status.state === 'warn' && <span style={{ color: '#8A6500', marginInlineStart: 8 }}>נשארו {fmtPrice(b.budget - status.total)}</span>}
                    </div>
                    {(status.state === 'ok' || status.state === 'warn') && i < baskets.length - 1 && (
                      <button onClick={() => setOpenBasket(baskets[i + 1].id)}
                        style={{ background: accent, color: 'white', border: '2px solid #1a1a1a',
                          padding: '6px 14px', borderRadius: 4, cursor: 'pointer',
                          fontFamily: 'inherit', fontWeight: 700, fontSize: 13, flexShrink: 0 }}>
                        המשך לסל הבא ←
                      </button>
                    )}
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sticky submit bar */}
      <div style={{
        position: 'fixed', bottom: 0, right: 0, left: 0,
        background: 'white', borderTop: '2px solid #1a1a1a',
        padding: '12px 20px', display: 'flex', alignItems: 'center', gap: 14, zIndex: 10,
      }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 11, color: '#998877', fontWeight: 600 }}>סך הכל ההצבעה</div>
          <div style={{ fontSize: 17, fontWeight: 800 }}>{fmtPrice(totalAll)} / {fmtPrice(budgetAll)}</div>
        </div>
        <button onClick={submit} disabled={!allValid}
          style={{ padding: '12px 22px', border: '2px solid #1a1a1a',
            background: allValid ? accent : '#f0e6d2', color: allValid ? 'white' : '#998877',
            fontFamily: 'inherit', fontWeight: 800, fontSize: 15,
            cursor: allValid ? 'pointer' : 'not-allowed', borderRadius: 4,
            boxShadow: allValid ? '3px 3px 0 #1a1a1a' : 'none' }}>
          {submitting ? '⏳ שולח...' : allValid ? 'שלח הצבעה ✓' : `${baskets.filter(b => { const t = basketTotal(state[b.id] || {}, products); return t > 0 && t <= b.budget; }).length}/4 הושלמו`}
        </button>
      </div>
    </div>
  );
}

window.VariantStepper = VariantStepper;
