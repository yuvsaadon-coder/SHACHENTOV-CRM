// Variation 1: Tabs + Grid (kartisiyot — כרטיסיות עם בורדר שחור, סגנון 2)
const { useState: useState1, useMemo: useMemo1 } = React;

function VariantTabsGrid({ coordinator, onLogout, accent }) {
  const [state, setState] = useCoordinatorState(`v1-${coordinator.id}`);
  const [activeBasket, setActiveBasket] = useState1('a');
  const [search, setSearch] = useState1('');

  const baskets = window.APP_DATA.baskets;
  const products = useMemo1(() => getVisibleProducts(coordinator.branch), [coordinator.branch]);

  const items = state[activeBasket] || {};
  const basket = baskets.find(b => b.id === activeBasket);
  const status = basketStatus(items, basket, products);

  // Locking: must complete previous baskets in order (i.e., not over budget AND has items)
  const isBasketUnlocked = (idx) => {
    if (idx === 0) return true;
    for (let i = 0; i < idx; i++) {
      const prev = state[baskets[i].id] || {};
      const prevTotal = basketTotal(prev, products);
      if (prevTotal === 0 || prevTotal > baskets[i].budget) return false;
    }
    return true;
  };

  const allBasketsValid = baskets.every((b, i) => {
    const its = state[b.id] || {};
    const t = basketTotal(its, products);
    return t > 0 && t <= b.budget;
  });

  const setQty = (pid, qty) => {
    const p = products.find(x => x.id === pid);
    if (!p) return;
    qty = Math.max(0, Math.min(qty, p.max));
    setState(s => ({ ...s, [activeBasket]: { ...(s[activeBasket] || {}), [pid]: qty } }));
  };

  const submit = () => {
    if (!allBasketsValid) return;
    setState(s => ({ ...s, _submitted: true, _submittedAt: Date.now() }));
    alert('ההצבעה נשלחה בהצלחה! תודה ' + coordinator.name);
  };

  const filtered = products.filter(p => !search || p.name.includes(search));

  return (
    <div style={{
      minHeight: '100%', direction: 'rtl', paddingBottom: 110,
      background: 'var(--bg, #FFF8EC)',
    }}>
      {/* Header */}
      <header style={{
        background: 'white', borderBottom: '2px solid #1a1a1a',
        padding: '14px 20px', display: 'flex', alignItems: 'center', gap: 16,
        position: 'sticky', top: 0, zIndex: 5,
      }}>
        <div style={{
          width: 36, height: 36, background: accent, color: 'white',
          display: 'grid', placeItems: 'center', fontWeight: 800, fontSize: 18,
          borderRadius: 4,
        }}>ש</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, color: '#998877', fontWeight: 500 }}>שלום,</div>
          <div style={{ fontSize: 16, fontWeight: 700 }}>
            {coordinator.name} <span style={{ color: '#998877', fontWeight: 500 }}>· סניף {coordinator.branch}</span>
          </div>
        </div>
        <button onClick={onLogout} style={{
          background: 'none', border: 'none', color: '#998877',
          fontFamily: 'inherit', cursor: 'pointer', fontSize: 14, padding: 8,
        }}>החלף משתמש</button>
      </header>

      {/* Basket tabs */}
      <div style={{
        background: 'white', borderBottom: '2px solid #1a1a1a',
        padding: '0 20px', display: 'flex', overflowX: 'auto',
        position: 'sticky', top: 65, zIndex: 4,
      }}>
        {baskets.map((b, i) => {
          const unlocked = isBasketUnlocked(i);
          const its = state[b.id] || {};
          const t = basketTotal(its, products);
          const valid = t > 0 && t <= b.budget;
          const active = activeBasket === b.id;
          return (
            <button
              key={b.id}
              disabled={!unlocked}
              onClick={() => unlocked && setActiveBasket(b.id)}
              style={{
                flex: '1 1 0', minWidth: 120, padding: '14px 12px',
                border: 'none', borderBottom: active ? `4px solid ${accent}` : '4px solid transparent',
                background: 'none', cursor: unlocked ? 'pointer' : 'not-allowed',
                fontFamily: 'inherit', textAlign: 'center',
                opacity: unlocked ? 1 : 0.4,
              }}
            >
              <div style={{ fontSize: 11, color: '#998877', fontWeight: 600, marginBottom: 2 }}>
                {!unlocked ? '🔒 נעול' : valid ? '✓ הושלם' : t > b.budget ? '⚠ חריגה' : 'בתהליך'}
              </div>
              <div style={{ fontSize: 14, fontWeight: 700, color: active ? accent : '#1a1a1a' }}>{b.name}</div>
              <div style={{ fontSize: 11, color: '#998877', marginTop: 2 }}>תקציב {b.budget}₪</div>
            </button>
          );
        })}
      </div>

      {/* Search */}
      <div style={{ padding: '16px 20px 0' }}>
        <input
          type="text" value={search} onChange={e => setSearch(e.target.value)}
          placeholder="חיפוש מוצר..."
          style={{
            width: '100%', boxSizing: 'border-box', padding: '12px 16px',
            border: '2px solid #1a1a1a', borderRadius: 4,
            fontSize: 15, fontFamily: 'inherit', background: 'white',
          }}
        />
      </div>

      {/* Product grid */}
      <div style={{
        padding: '16px 20px',
        display: 'grid', gap: 12,
        gridTemplateColumns: 'repeat(auto-fill, minmax(170px, 1fr))',
      }}>
        {filtered.map(p => {
          const qty = items[p.id] || 0;
          const subtotal = qty * p.price;
          return (
            <div key={p.id} style={{
              background: 'white', border: '2px solid #1a1a1a', borderRadius: 4,
              display: 'flex', flexDirection: 'column',
              boxShadow: qty > 0 ? `4px 4px 0 ${accent}` : '4px 4px 0 #1a1a1a',
              transition: 'box-shadow 0.15s',
            }}>
              <div style={{
                height: 96, background: '#F5EFE0',
                display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10,
                padding: '0 12px',
                borderBottom: '2px solid #1a1a1a', position: 'relative',
              }}>
                <span style={{ fontSize: 44, lineHeight: 1 }}>{p.emoji}</span>
                <span style={{ fontSize: 16, fontWeight: 800, color: '#1a1a1a', textAlign: 'right', lineHeight: 1.1 }}>{p.name}</span>
                {p.max < 10 && (
                  <div style={{
                    position: 'absolute', top: 6, right: 6,
                    background: '#1a1a1a', color: 'white', fontSize: 10, fontWeight: 700,
                    padding: '2px 6px', borderRadius: 2,
                  }}>מקס {p.max}</div>
                )}
              </div>
              <div style={{ padding: '10px 12px', flex: 1 }}>
                <div style={{ fontSize: 12, color: '#998877' }}>{fmtPrice(p.price)} ליחידה</div>
                {qty > 0 && (
                  <div style={{ fontSize: 12, color: accent, fontWeight: 700, marginTop: 4 }}>
                    סה"כ: {fmtPrice(subtotal)}
                  </div>
                )}
              </div>
              <div style={{
                display: 'flex', borderTop: '2px solid #1a1a1a',
              }}>
                <button onClick={() => setQty(p.id, qty - 1)} disabled={qty === 0}
                  style={{
                    flex: 1, padding: '10px 0', border: 'none',
                    background: qty === 0 ? '#f0e6d2' : 'white',
                    cursor: qty === 0 ? 'not-allowed' : 'pointer',
                    fontFamily: 'inherit', fontSize: 18, fontWeight: 700,
                    borderLeft: '1px solid #1a1a1a',
                  }}>−</button>
                <div style={{
                  flex: 1, display: 'grid', placeItems: 'center',
                  fontSize: 16, fontWeight: 800,
                  background: qty > 0 ? accent : 'white',
                  color: qty > 0 ? 'white' : '#1a1a1a',
                  borderLeft: '1px solid #1a1a1a',
                }}>{qty}</div>
                <button onClick={() => setQty(p.id, qty + 1)} disabled={qty >= p.max}
                  style={{
                    flex: 1, padding: '10px 0', border: 'none',
                    background: qty >= p.max ? '#f0e6d2' : 'white',
                    cursor: qty >= p.max ? 'not-allowed' : 'pointer',
                    fontFamily: 'inherit', fontSize: 18, fontWeight: 700,
                  }}>+</button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Sticky budget bar */}
      <BudgetBar status={status} basket={basket} accent={accent}
        canSubmit={allBasketsValid && activeBasket === baskets[baskets.length - 1].id}
        onSubmit={submit}
      />
    </div>
  );
}

function BudgetBar({ status, basket, accent, canSubmit, onSubmit }) {
  const colors = {
    empty: '#998877',
    ok: '#1B5E3F',
    warn: '#D88F00',
    over: '#C81D11',
  };
  const labels = {
    empty: 'התחל לבחור מוצרים',
    ok: 'בתוך התקציב',
    warn: 'מתקרב/ת לגבול',
    over: 'חריגה מהתקציב',
  };
  const c = colors[status.state];
  const pct = Math.min(status.pct, 100);

  return (
    <div style={{
      position: 'fixed', bottom: 0, right: 0, left: 0,
      background: 'white', borderTop: '2px solid #1a1a1a',
      padding: '12px 20px', zIndex: 10,
      boxShadow: '0 -4px 0 rgba(0,0,0,0.05)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 8 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 11, color: '#998877', fontWeight: 600 }}>{basket.name} · {labels[status.state]}</div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>
            <span style={{ color: c }}>{fmtPrice(status.total)}</span>
            <span style={{ color: '#998877', fontSize: 14, fontWeight: 600 }}> / {fmtPrice(basket.budget)}</span>
          </div>
        </div>
        <button onClick={onSubmit} disabled={!canSubmit}
          style={{
            padding: '10px 18px', border: '2px solid #1a1a1a',
            background: canSubmit ? accent : '#f0e6d2',
            color: canSubmit ? 'white' : '#998877',
            fontFamily: 'inherit', fontWeight: 700, fontSize: 14,
            cursor: canSubmit ? 'pointer' : 'not-allowed',
            borderRadius: 4, boxShadow: canSubmit ? '3px 3px 0 #1a1a1a' : 'none',
          }}>שלח הצבעה</button>
      </div>
      <div style={{
        height: 8, background: '#F5EFE0', border: '1.5px solid #1a1a1a', borderRadius: 0,
        overflow: 'hidden', position: 'relative',
      }}>
        <div style={{
          height: '100%', width: pct + '%',
          background: c, transition: 'width 0.2s, background 0.2s',
        }} />
        {status.state === 'over' && (
          <div style={{
            position: 'absolute', inset: 0,
            backgroundImage: 'repeating-linear-gradient(45deg, transparent, transparent 6px, rgba(0,0,0,0.15) 6px, rgba(0,0,0,0.15) 12px)',
          }} />
        )}
      </div>
    </div>
  );
}

window.VariantTabsGrid = VariantTabsGrid;
window.BudgetBar = BudgetBar;
